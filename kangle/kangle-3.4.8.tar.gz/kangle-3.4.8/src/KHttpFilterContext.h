#ifndef KHTTPFILTERCONTEXT_H
#define KHTTPFILTERCONTEXT_H
#include "global.h"
#include "ksapi.h"
#include <assert.h>
#include <stdlib.h>
class KHttpRequest;
#ifdef ENABLE_KSAPI_FILTER
struct KHttpFilterRequestContext
{
	void *ctx;
	DWORD disabled_flags;
};
class KHttpFilterContext
{
public:
	KHttpFilterContext();
	~KHttpFilterContext();
	void init(KHttpRequest *rq);
	DWORD restore(int index,void *model_ctx=NULL)
	{
		ctx.pFilterContext = filterContext[index].ctx;
		ctx.ulReserved = index;
		ctx.pModelContext = model_ctx;
		return filterContext[index].disabled_flags;
	}
	void save(int index)
	{
		assert(index == ctx.ulReserved);
		filterContext[index].ctx = ctx.pFilterContext;
		ctx.pModelContext = NULL;
	}
	kgl_filter_context ctx;
	KHttpFilterRequestContext *filterContext;
};
KGL_RESULT add_api_var(LPVOID buffer, LPDWORD size, const char *val, int len =0);
#endif
#endif
