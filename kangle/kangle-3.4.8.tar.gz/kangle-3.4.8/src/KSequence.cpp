#include "KSequence.h"

KSequence sequence;
