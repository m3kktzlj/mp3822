/*
 * KServiceProvider.cpp
 *
 *  Created on: 2010-8-7
 *      Author: keengo
 */

#include "KServiceProvider.h"

KServiceProvider::KServiceProvider() {
	// TODO Auto-generated constructor stub

}

KServiceProvider::~KServiceProvider() {
	// TODO Auto-generated destructor stub
}
