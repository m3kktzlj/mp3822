#include "KListNode.h"

KListNode::KListNode(void)
{
	next = prev = NULL;
}

KListNode::~KListNode(void)
{
}
