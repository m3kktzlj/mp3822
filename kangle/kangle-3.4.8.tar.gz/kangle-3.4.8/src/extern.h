#if	!defined(_EXTERN_H_INCLUDED_)
#define _EXTERN_H_INCLUDED_
extern volatile int quit_program_flag;
extern volatile int stop_service_sig;
extern volatile bool autoupdate_thread_started;
extern int my_uid;
extern int api_child_key;
extern int serial;

#endif	/* !_EXTERN_H_INCLUDED_ */
