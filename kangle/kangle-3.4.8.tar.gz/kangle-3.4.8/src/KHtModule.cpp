/*
 * KHtModule.cpp
 *
 *  Created on: 2010-9-27
 *      Author: keengo
 */

#include "KHtModule.h"

KHtModule::KHtModule() {
	// TODO Auto-generated constructor stub

}

KHtModule::~KHtModule() {
	// TODO Auto-generated destructor stub
}
