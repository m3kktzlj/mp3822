/*
 * KSSICommand.cpp
 *
 *  Created on: 2010-8-2
 *      Author: keengo
 */

#include "KSSICommand.h"

KSSICommand::KSSICommand() {

}
KSSICommand::~KSSICommand() {
}
