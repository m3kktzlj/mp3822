/*
 * KRedirect.cpp
 *
 *  Created on: 2010-6-12
 *      Author: keengo
 */

#include "KRedirect.h"
#include "server.h"

KRedirect::KRedirect() {
	enable = true;
	ext = cur_config_ext;
}

KRedirect::~KRedirect() {
}
