#include "global.h"
#include "KResponseContext.h"

/*
void KResponseContext::clean()
{
	if(header){
		KBuffer::destroy(header);
		header = NULL;
	}
	body = NULL;
	hot_buffer = NULL;
	body_start = 0;
	body_len = 0;
	send_size = 0;
	header_size = 0;
}
*/