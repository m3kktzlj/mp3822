/*
 * KCdnMysqlMark.cpp
 *
 *  Created on: 2010-11-9
 *      Author: keengo
 */

#include "KCdnMysqlMark.h"
#include "KThreadPool.h"
#include "kmysql.h"
#include "lib.h"
#include "KHttpProxyFetchObject.h"
#include "KCdnContainer.h"


