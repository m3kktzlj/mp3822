#include "KList.h"

KList::KList(void)
{
		head = NULL;
		end = NULL;
}

KList::~KList(void)
{
}
